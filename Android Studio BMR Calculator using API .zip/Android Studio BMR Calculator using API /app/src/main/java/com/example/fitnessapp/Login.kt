package com.example.fitnessapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.fitnessapp.ui.theme.FitnessAppTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException

class Login : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FitnessAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Conta()
                }
            }
        }
    }
}

@Composable
fun Conta() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            Login {
                navController.navigate("registar")
            }
        }
        composable("registar") {
            RegistarConta {
                navController.navigate("login")
            }
        }

    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistarConta(onRegistoClick: () -> Unit) {
    var txtMail by remember { mutableStateOf("") }
    var txtPass by remember { mutableStateOf("") }
    var txtFullName by remember { mutableStateOf("") }
    var btnResgistar by remember { mutableStateOf("Criar Conta") }

    val firebaseAuth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    Box(modifier = Modifier.fillMaxSize())
    {
        Image(painter = painterResource(R.drawable.background),
            contentDescription = "Imagem de Fundo",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds)
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "Imagem de Topo",
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp),
            contentScale = ContentScale.FillBounds
        )

        Spacer(Modifier.height(16.dp))
        Spacer(Modifier.height(16.dp))

        Text(
            text = "Registar",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            style = TextStyle(
                textAlign = TextAlign.Center
            )
        )

        TextField(
            modifier = Modifier.fillMaxWidth(),
            value = txtFullName,
            onValueChange = { newFullName -> txtFullName = newFullName },
            label = { Text("Nome") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            modifier = Modifier.fillMaxWidth(),
            value = txtMail,
            onValueChange = { newEmail -> txtMail = newEmail },
            label = { Text("Email") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            modifier = Modifier.fillMaxWidth(),
            value = txtPass,
            onValueChange = { newPassword -> txtPass = newPassword },
            label = { Text("Palavra-Passe") },
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val fullName = txtFullName
                val email = txtMail
                val password = txtPass

                firebaseAuth.fetchSignInMethodsForEmail(email).addOnCompleteListener { task ->
                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener { creationTask ->
                            if (creationTask.isSuccessful) {
                                onRegistoClick.invoke()
                            } else {
                                btnResgistar = "Email já registado, tente outro"
                                txtMail = ""
                                txtPass = ""
                                txtFullName = ""
                            }
                        }
                }
            }
        ) {
            Text(btnResgistar)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Login(onLoginClick: () -> Unit) {
    var txtMail by remember { mutableStateOf("") }
    var txtPass by remember { mutableStateOf("") }
    var btnEntrar by remember { mutableStateOf("Entrar") }
    var btnResgistar by remember { mutableStateOf("Criar Conta") }

    val context = LocalContext.current

    val firebaseAuth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    Box(modifier = Modifier.fillMaxSize())
    {
        Image(painter = painterResource(R.drawable.background),
            contentDescription = "Imagem de Fundo",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "Imagem de Topo",
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp),
            contentScale = ContentScale.FillBounds
        )

        Spacer(Modifier.height(16.dp))
        Spacer(Modifier.height(16.dp))

        Text(
            text = "Login",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            style = TextStyle(
                textAlign = TextAlign.Center
            )
        )
        TextField(
            modifier = Modifier.fillMaxWidth(),
            value = txtMail,
            onValueChange = { newEmail -> txtMail = newEmail },
            label = { Text("Email") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            modifier = Modifier.fillMaxWidth(),
            value = txtPass,
            onValueChange = { newPassword -> txtPass = newPassword },
            label = { Text("Palavra-Passe") },
            visualTransformation = PasswordVisualTransformation()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val email = txtMail
                val password = txtPass

                firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val user = firebaseAuth.currentUser
                            val intent = Intent(context, MainActivity::class.java)
                            context.startActivity(intent)
                        } else {
                            if (task.exception is FirebaseAuthInvalidCredentialsException) {
                                btnEntrar = "Erro ao entrar, verifique os dados e clique aqui novamente"
                            }
                            txtMail = ""
                            txtPass = ""
                        }
                    }
            }
        ) {
            Text(btnEntrar)
        }

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                onLoginClick.invoke()
            }
        ) {
            Text(btnResgistar)
        }

    }
}
