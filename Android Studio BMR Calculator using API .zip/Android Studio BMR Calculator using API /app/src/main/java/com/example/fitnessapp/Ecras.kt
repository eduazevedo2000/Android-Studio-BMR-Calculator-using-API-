package com.example.fitnessapp

import android.annotation.SuppressLint
import android.content.Context
import android.net.http.HttpResponseCache.install
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.SnackbarDefaults.backgroundColor
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItemDefaults.contentColor
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import io.ktor.client.HttpClient
import io.ktor.client.features.get
import io.ktor.client.features.json.GsonSerializer
import io.ktor.client.features.json.JsonFeature
import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.utils.EmptyContent.headers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONException
import org.json.JSONObject


@Composable
fun Ecra01() {
    Box(modifier = Modifier.fillMaxSize())
    {
        Image(painter = painterResource(R.drawable.background),
            contentDescription = "Imagem de Fundo",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds)
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "Imagem de Topo",
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp),
            contentScale = ContentScale.FillBounds
        )

        // Espaço entre a imagem e o texto
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Bem-vindo à Healthy Check",
            style = TextStyle(
                color = Color.Black,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
        )

        Text(
            text = "A Healthy Check é uma aplicação dedicada ao bem-estar que coloca o controlo da sua saúde nas suas mãos. Com a capacidade de calcular o seu BMR (Taxa Metabólica Basal), a aplicação fornece uma visão personalizada das suas necessidades calóricas diárias. Seja qual for o seu objetivo - perder peso, ganhar massa muscular ou manter um estilo de vida saudável - a Healthy Check ajusta as recomendações de ingestão de calorias para atender às suas metas específicas.",
            style = TextStyle(
                color = Color.Black,
                fontSize = 20.sp,
                fontWeight = FontWeight.Normal
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ecra02(navController: NavController) {
    var altura by remember { mutableStateOf(TextFieldValue()) }
    var peso by remember { mutableStateOf(TextFieldValue()) }
    var idade by remember { mutableStateOf(TextFieldValue()) }
    var nivelAtividade by remember { mutableStateOf(1f) }
    var resultadoApi by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize())
    {
        Image(painter = painterResource(R.drawable.background),
            contentDescription = "Imagem de Fundo",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds)
    }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(text = "Preencha com os seus dados!" , color = Color.Black, fontSize = 20.sp)
            Spacer(Modifier.height(16.dp))
            Spacer(Modifier.height(16.dp))
            TextField(
                value = altura,
                onValueChange = { altura = it },
                label = { Text("Altura (cm)") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )
            TextField(
                value = peso,
                onValueChange = { peso = it },
                label = { Text("Peso (kg)") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )
            TextField(
                value = idade,
                onValueChange = { idade = it },
                label = { Text("Idade") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )
            Spacer(Modifier.height(16.dp))
            Spacer(Modifier.height(16.dp))
            Text(text = "Nivel de Atividade", color = Color.Black)
            Slider(
                value = nivelAtividade,
                onValueChange = { nivelAtividade = it },
                valueRange = 1f..6f,
                steps = 5,
                modifier = Modifier
                    .padding(vertical = 16.dp)
                    .fillMaxWidth()
            )
            Button(
                onClick = {
                    val altura = altura
                    val peso = peso
                    val idade = idade
                    val nivelAtividade = nivelAtividade

                    calcularBMR(
                        altura.text,
                        peso.text,
                        idade.text,
                        nivelAtividade
                    ) { resultado ->
                        resultadoApi = resultado
                    }
                },
                modifier = Modifier
                    .padding(top = 16.dp)
                    .width(200.dp)

            ) {
                Text("Calcular BMR")
            }
            resultadoApi?.let { rawResult ->
                val formattedResult = formatApiResponse(rawResult)
                Text("$formattedResult", modifier = Modifier.padding(top = 16.dp), color = Color.Black)
            }
        }
    }


fun calcularBMR(altura: String, peso: String, idade: String, nivelAtividade: Float, callback: (String) -> Unit) {
    val client = OkHttpClient()

    val url = "https://fitness-calculator.p.rapidapi.com/dailycalorie?" +
            "age=$idade&gender=male&height=$altura&weight=$peso&activitylevel=level_${nivelAtividade.toInt()}"

    val request = Request.Builder()
        .url(url)
        .get()
        .addHeader("X-RapidAPI-Key", "197bad95e6mshd1e4936ac4751e5p149bfdjsn250bad6ab413")
        .addHeader("X-RapidAPI-Host", "fitness-calculator.p.rapidapi.com")
        .build()

    CoroutineScope(Dispatchers.IO).launch {
        try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            callback(responseBody ?: "Erro na chamada da API")
        } catch (e: Exception) {
            callback("Erro na chamada da API: ${e.message}")
        }
    }
}

@SuppressLint("SuspiciousIndentation")
fun formatApiResponse(rawResult: String): String {
    return try {
        val json = JSONObject(rawResult)
        val bmr = json.getJSONObject("data").getDouble("BMR")
        val maintainWeight = json.getJSONObject("data").getJSONObject("goals").getDouble("maintain weight")
        val mildWeightLoss = json.getJSONObject("data").getJSONObject("goals").getJSONObject("Mild weight loss").getDouble("calory")
        val weightLoss = json.getJSONObject("data").getJSONObject("goals").getJSONObject("Weight loss").getDouble("calory")
        val extremeWeightLoss = json.getJSONObject("data").getJSONObject("goals").getJSONObject("Extreme weight loss").getDouble("calory")
        val mildWeightGain = json.getJSONObject("data").getJSONObject("goals").getJSONObject("Mild weight gain").getDouble("calory")
        val weightGain = json.getJSONObject("data").getJSONObject("goals").getJSONObject("Weight gain").getDouble("calory")
        val extremeWeightGain = json.getJSONObject("data").getJSONObject("goals").getJSONObject("Extreme weight gain").getDouble("calory")

                "BMR: $bmr\n" +
                "Manter Peso: $maintainWeight\n" +
                "Perder 0,25kg / semana: $mildWeightLoss\n" +
                "Perder 0,5kg / semana: $weightLoss\n" +
                "Perder 1kg / semana: $extremeWeightLoss\n" +
                "Ganhar 0,25kg / semana: $mildWeightGain\n" +
                "Ganhar 0,5kg / semana: $weightGain\n" +
                "Ganhar 1kg / semana: $extremeWeightGain"

    } catch (e: JSONException) {
        "Erro na formatação da resposta da API"
    }
}

